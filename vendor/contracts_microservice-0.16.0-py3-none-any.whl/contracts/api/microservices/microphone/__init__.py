"""Microphone contracts."""
